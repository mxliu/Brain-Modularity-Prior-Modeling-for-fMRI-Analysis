BMR 
This is the code for our paper "Leveraging Brain Modularity Prior for Interpretable Representation Learning of fMRI"