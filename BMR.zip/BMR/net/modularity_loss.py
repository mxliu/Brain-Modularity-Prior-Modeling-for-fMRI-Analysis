import itertools
from scipy.spatial.distance import cosine
import random
import warnings
warnings.filterwarnings('ignore')
import numpy as np
a1=[29,30,41,42,71,72,73,74,75,76,81,82,83,84,87,88]#original index of ROIs in SN
a2=[23,24,25,26,31,32,35,36,37,38,39,40,61,62,63,64,65,66,67,68,89,90]#DMN
a3=[3,4,7,8,59,60,13,14,15,16]#CEN
list1=(np.array(a1)-1).tolist()
list2=(np.array(a2)-1).tolist()
list3=(np.array(a3)-1).tolist()
m=0.5
IDX1=list(itertools.combinations(list1, 2)) #pairwise index in modularity1
IDX1=random.choices(IDX1, k=int(len(IDX1)*m))
IDX2=list(itertools.combinations(list2, 2)) #pairwise index in modularity2
IDX2=random.choices(IDX2, k=int(len(IDX2)*m))
IDX3=list(itertools.combinations(list3, 2)) #pairwise index in modularity3
IDX3=random.choices(IDX3, k=int(len(IDX3)*m))
Idx_set=[IDX1,IDX2,IDX3]
def calculateloss(X):
    list3=[]
    for k in range(len(X)):
        x=X[k]
        list2 = []
        for j in range(3):
            IDX = Idx_set[j]
            list1 = []
            for i, (a, b) in enumerate(IDX):
                roi1 = x[a, :].cpu().detach().numpy()  # (64,)
                roi2 = x[b, :].cpu().detach().numpy()  # (64,)
                # print(roi2.shape)
                cos = -cosine(roi1, roi2)
                list1.append(cos)
            loss1 = np.sum(list1)
            list2.append(loss1)
       # print(len(list2))
        loss2 = np.sum(list2)
        list3.append(loss2)
    loss3 = np.sum(list3)
    return loss3